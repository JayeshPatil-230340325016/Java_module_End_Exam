package ques3;

public class Employee {

	private String firstName;
	private String lastName;
	private int id;
	private double salary;
	
	public Employee(String firstName, String lastName, int id, double salary) {
		//super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		this.salary = salary;
		
		System.out.println("Employee First Name -> \t"+firstName+"\nEmployee Last Name -> \t"+lastName+"\nEmployee ID -> \t\t"+id+"\nEmployee Salary -> \t"+salary);
	}
	
	
	public Employee(String firstName, String lastName, int id) {
		//super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		
		System.out.println("Employee First Name -> \t"+firstName+"\nEmployee Last Name -> \t"+lastName+"\nEmployee ID -> \t\t"+id);
	}
	

}
