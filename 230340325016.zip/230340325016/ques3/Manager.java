package ques3;

public class Manager extends Employee{
	
	private String department;

	public Manager(String firstName, String lastName, int id, double salary, String department) {
		super(firstName, lastName, id, salary);
		this.department=department;
		System.out.println("Employee Department ID -> \t"+department);

		
	}

	public Manager(String firstName, String lastName, int id, String department) {
		super(firstName, lastName,id);
		this.department = department;
		
		System.out.println("Employee Department ID -> \t"+department);
	

	}
	
	
	

}
