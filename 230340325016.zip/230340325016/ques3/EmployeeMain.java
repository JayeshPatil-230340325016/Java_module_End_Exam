package ques3;

import java.util.Scanner;

public class EmployeeMain {

	public static void main(String[] args) {

		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Employee firstname, lastname, id, salary");
		
		String fname=sc.next();
		String lname=sc.next();
		int id=sc.nextInt();
		double sal=sc.nextDouble();

		
		
		Employee e = new Employee(fname, lname, id, sal);
		
		System.out.println();
		System.out.println("Enter Manager firstname, lastname, id, department");
		
		fname=sc.next();
		lname=sc.next();
		id=sc.nextInt();
		String dept=sc.next();
		
		
		Employee f = new Manager(fname, lname, id, dept);
		System.out.println();
		
		
		System.out.println("Enter Manager firstname, lastname, id, salary, department");
		
		fname=sc.next();
		lname=sc.next();
		id=sc.nextInt();
		sal=sc.nextDouble();
		dept=sc.next();
		
		Employee g = new Manager(fname, lname, id, sal, dept);
		
		
		sc.close();
	}

}
