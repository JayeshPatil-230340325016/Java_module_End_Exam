package ques1;

import java.util.ArrayList;
import java.util.Scanner;

public class BankMain {

	public static void main(String[] args) {
		
		ArrayList<Bank> alb = new ArrayList<Bank>();
		Scanner sc = new Scanner(System.in);
			boolean start=true;
			
			Bank b =new Bank();
			System.out.println("Welcome to our bank\n");
			while(start) {
				
				System.out.println("\nEnter 1. Create Account, 2. Deposit Money, 3. Withdraw, "
						+ "4.Display Account Balance 5. Quit");
				int ch=sc.nextInt();
				
				switch (ch) {
				case 1:
					{
						Bank newacc= new Bank();
						System.out.println("Enter Customer name");
						String name=sc.nextLine();
						sc.next();
						
						System.out.println("Enter Customer account number");
						int acc=sc.nextInt();
						
						System.out.println("Enter initial balance");
						double bal=sc.nextDouble();
						
						newacc.createAccount(name, acc, bal);
						System.out.println("Account created successfully");
						
						alb.add(newacc);
						break;
					}
					
				
				case 2:
					{
						System.out.println("Enter Account number to deposit amount");
					
					int acn=sc.nextInt();
					boolean flagD=false;
				
					for (Bank t: alb) {
						if(t.getAccno()==acn) {
							System.out.println("Enter amount to add deposit");
							flagD=t.addDeposit(sc.nextDouble());
					}
					
					}
					
					
					if(flagD)
						System.out.println("Amount added successfully");
					
					else
						System.out.println("Wrong Amount entered. Try again");
					break;	
					}
					
				case 3:
				{
					System.out.println("Enter Account number to withdraw amount");
					
					int acn=sc.nextInt();
					boolean flagD=false;
					
					for (Bank t: alb) {
						if(t.getAccno()==acn) {
							System.out.println("Enter amount to withdraw");
							flagD=t.withdraw(sc.nextDouble());
					}
					
					}

					
					if(flagD)
						System.out.println("Amount withdrawn successfully");
					
					else {
						System.out.println("Wrong Amount entered. Try again");
						
					}
		
					break;	
				}
					case 4:
					{
						System.out.println("Enter account number to check balance");
						int acn=sc.nextInt();
						boolean flag=false;
						for (Bank t: alb) {
							if(t.getAccno()==acn) {
								t.displayBalance(acn);
								flag=true;
								break;
								
						}
							
						}
						
						if(!flag) {
							System.out.println("Wrong account number entered");
						}
						
					
						break;
					}
					
				
					
				case 5:
					start=false;
					System.out.println("Thank you for visiting us");
					break;
	

				default:
					System.out.println("Wrong Choice.. Please enter again");;
				}

			

			}
sc.close();
	}
}