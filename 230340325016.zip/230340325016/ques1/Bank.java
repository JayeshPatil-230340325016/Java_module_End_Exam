package ques1;

public class Bank {
	
	private String name;
	private int accno;
	private double balance;
	
	public String getName() {
		return name;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}

	public int getAccno() {
		return accno;
	}

	public void setAccno(int accno) {
		this.accno = accno;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public Bank() {
		super();
	}

	
	public void createAccount(String name, int accno, double balance) {
		
		this.name = name;
		this.accno = accno;
		this.balance = balance;
		
		
	}
	
	
	public boolean addDeposit(double amt) {
		
		if(amt<=0 || Double.isNaN(amt))
		{
			return false;
		}
		
		else {
			balance=balance+amt;
			
			return true;	
		}
		
	}
	
	public boolean withdraw(double amt) {
		
		if(amt<=0){
			System.out.println("amount cannot be negative");
			return false;
		}
		
		else if((balance-amt)<=0) {
			System.out.println("Balance insufficient");
			return false;
		}
		
		else {
			
			balance=balance-amt;
			return true;
			
		}
		
	}
	
	public void displayBalance(int acc) {
		if(accno==acc) {
			System.out.println("Your balance :"+balance);
		}
		
	}
	

}
